/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pregunta2;

/**
 *
 * @author Estudiante
 */
public class MiNumero {
    int num;
    
   public MiNumero(int num){
       this.num = num;
   }
   public int valorAbs(){
       return Math.abs(this.num);
   }
   public int cuadrado(){
       return this.num * this.num;
   }
   public boolean paryImpar(){
   if(num % 2 == 0){
       return true;
   }    
   else{
       return false;
   }

}
 public int positivoYNegativo(){
    if(this.num < 0){
        return -1;
    }
    else if(this.num > 0){
        return 1;
    }
    else{
        return 0;
    }
 }
 public int unidades (){
    return this.num % 10;
 } 
}                                                                                                                 

