/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pregunta2;

import java.util.Scanner;

public class Pregunta2 {
    public static void main(String[] args) {
        int num = 0;
        MiNumero numero1;
       Scanner scan = new Scanner (System.in);
        System.out.println("Dijite el numero");
         num = scan.nextInt();
         
         numero1 = new MiNumero(num);
         System.out.println(numero1.valorAbs());
         System.out.println(numero1.cuadrado());
         System.out.println(numero1.paryImpar());
         System.out.println(numero1.positivoYNegativo());
         System.out.println(numero1.unidades());




    }

    
}
