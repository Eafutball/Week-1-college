import java.util.Scanner;

public class Pregunta3 {
    public static void main(String[] args) throws Exception {

        int codVendedor = 0;
        double salarioBase = 0;
        char sexo;
        int codComision = 0;
        Vendedor maria;
        
        Scanner inputScanner = new Scanner(System.in);
        System.out.println("Ingrese el código del vendedor: ");
        codVendedor = inputScanner.nextInt();

        System.out.println("Ingrese el salario base: ");
        salarioBase = inputScanner.nextDouble();

        System.out.println("Ingrese el género (M/F): ");
        sexo = inputScanner.next().charAt(0);

        System.out.println("Ingrese el código de comisión: ");
        codComision = inputScanner.nextInt();

        if (codComision < 7) {
            maria = new Vendedor(codVendedor, salarioBase, sexo, codComision);
            System.out.println("El salario de María es: " + maria.salarioTotal(30000));
        }
    }
}



   



    

