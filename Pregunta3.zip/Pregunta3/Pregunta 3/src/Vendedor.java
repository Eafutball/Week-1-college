public class Vendedor {
    private int codVendedor;
    private double salarioBase;
    private char sexo;
    private int codComision;
  
    public Vendedor(int codVendedor, int salarioBase, char sexo, int codComision){
       this.codVendedor = codVendedor;
       this.salarioBase = salarioBase;
      this.sexo = sexo;
      this.codComision = codComision;
    }

    public double salarioTotal(int montodeVenta){ 
      double comision = 0.0;
      switch(this.codComision){
          case 1: 
          if( sexo == 'F'){
               comision = montodeVenta * 0.10;
          }
          else if (sexo == 'M'){
               comision = montodeVenta * 0.05;
          }
          break;
          case 2:
          case 3:
          case 4:
          case 5:
          case 7:
            if(montodeVenta <= 10000){
              comision = (montodeVenta - 10000) * 0.05;
          }
           else if(montodeVenta > 10000){
              comision = (montodeVenta - 10000) * 0.1;
           }
           default:
           comision = montodeVenta * 0.015;
      }
      return this.salarioBase + comision;
          
      }
    }

